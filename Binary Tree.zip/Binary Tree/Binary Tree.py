# Programming Assignment 2
# Aarav Patel
# CS610
from tkinter import Tk, Label

#class to build the tree with nodes
class build_Tree:
    def __init__(self, root=None, left_child=None, right_child=None):
        self.root = root
        self.left_child = left_child
        self.right_child = right_child

#get the height of the tree
def height(tree):
    if tree.right_child == None and tree.left_child == None:
        return 0
    else:
        return 1 + max(height(tree.left_child), height(tree.right_child))

#draw the tree and return the window
def drawtree(window, tree, x, y):
    #draw the node
    node = Label(window, text=tree.root, borderwidth=2, relief="solid", font=(18))
    node.grid(row=x, column=y)
    
    #draw left_childs
    if tree.left_child != None:
        h = height(tree)
        nbar = pow(2, h - 1)
        for i in range(1, nbar + 1):
            node = Label(window, text="L")
            node.grid(row=x - i, column=y - i)

            drawtree(window, tree.left_child, x - nbar, y - nbar)
    
    #draw right childs
    if tree.right_child != None:
        h = height(tree)
        nbar = pow(2, h - 1)
        for i in range(1, nbar + 1):
            node = Label(window, text="R")
            node.grid(row=x + i, column=y - i)
            drawtree(window, tree.right_child, x + nbar, y - nbar)

    return window

#expression rule
def expression(exptree):
    factortree = build_Tree()
    factortree = factor(factortree)

    if token == "*":
        #creates exp tree * as a parent
        exptree.root = "*"
        exptree.left_child = factortree

        right_exptree = build_Tree()
        gettoken()
        right_exptree = expression(right_exptree)
        exptree.right_child = right_exptree

    else:
        if token == "/":
            ##creates exp tree / as a parent
            exptree.root = "/"
            exptree.left_child = factortree

            right_exptree = build_Tree()
            gettoken()
            right_exptree = expression(right_exptree)
            exptree.right_child = right_exptree

        else:
            exptree = factortree
    return exptree

#factor rule
def factor(factortree):
    termtree = build_Tree()
    termtree = term(termtree)

    if gettoken() == "+":
        #creates factor tree + as a parent
        factortree.root = "+"
        factortree.left_child = termtree

        right_factortree = build_Tree()
        gettoken()
        right_factortree = factor(right_factortree)
        factortree.right_child = right_factortree

    else:
        if token == "-":
            #creates factor tree - as a parent
            factortree.root = "-"
            factortree.left_child = termtree

            right_factortree = build_Tree()
            gettoken()
            right_factortree = factor(right_factortree)
            factortree.right_child = right_factortree

        else:
            factortree = termtree
    return factortree

#term rule
def term(termtree):
    if (token) == "{":
        gettoken()
        termtree = expression(termtree)
        gettoken()
        return termtree
    else:
        lit_Tree = build_Tree(token)
        return lit_Tree

#computes the tree
def evaluate(evltree):
    if evltree.right_child == None and evltree.left_child == None:
        return evltree.root
    else:
        if evltree.root == "+":
            return int(evaluate(evltree.left_child)) + int(
                evaluate(evltree.right_child)
            )
        elif evltree.root == "-":
            return int(evaluate(evltree.left_child)) - int(
                evaluate(evltree.right_child)
            )
        elif evltree.root == "*":
            return int(evaluate(evltree.left_child)) * int(
                evaluate(evltree.right_child)
            )
        elif evltree.root == "/":
            return int(evaluate(evltree.left_child)) / int(
                evaluate(evltree.right_child)
            )

#get the next token
def gettoken():
    terminal_symbol = [
        "*",
        "/",
        "+",
        "-",
        "{",
        "}",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
    ]
    global token_index
    global token
    token_indextemp = token_index

    for x in range(token_index, len(numeric_exp)):
        if numeric_exp[x] in terminal_symbol:
            token_index = token_indextemp + 1
            token = numeric_exp[x]
            return token
    return None


if __name__ == "__main__":
    
    #numeric_expression
    numeric_exp = "9*7+6-8/2"
    
    #other exps for test 1 exp at a time
    #numeric_exp = "8/4/2"
    #numeric_exp = "{5+6/2}"
    #numeric_exp = "8+2/7+2/3+2"

    token, token_index = numeric_exp[0], 1
    print("\nNumeric Expression:", numeric_exp)

    #Build a tree
    tree = build_Tree()
    exptree = expression(tree)

    #Evaluate the Tree
    result = evaluate(exptree)
    print("\nEvaluation result(int):", int(result))

    #Draw a Tree
    window = Tk()
    window.geometry("800x800")
    window.title("Binary Tree")
    window = drawtree(window, exptree, 200, 200)
    window.mainloop()

