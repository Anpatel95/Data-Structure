#Aarav Patel
#Programming Assignment 3
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import random

random.seed(2)
np.random.seed(2)

#case 1 (gM and gPlus is same as g)
n = 6
g = [[0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 1], [0, 0, 0, 1, 0, 0]]
gM = [[0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 1], [0, 0, 0, 1, 0, 0]]
gPlus = [[0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 1], [0, 0, 0, 1, 0, 0]]

#case 2 (gM and gPlus is same as g)
# n = 6
# g = [[0, 1, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 1], [0, 0, 0, 0, 1, 0]]
# gM = [[0, 1, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 1], [0, 0, 0, 0, 1, 0]]
# gPlus = [[0, 1, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 1], [0, 0, 0, 0, 1, 0]]

#case 3 (gM and gPlus is same as g)
# n = 8
# g = [[0, 1, 0, 0, 0, 0,0,0], [0, 0, 1, 0, 0, 0,0,0], [0, 0, 0, 1, 0, 0,0,0], [0, 0, 0, 0, 1, 0,0,0], [0, 0, 0, 0, 0, 1,0,0], [0, 0, 0, 0, 0, 0,1,0], [0, 0, 0, 0, 0, 0,0,1], [0, 0, 0, 0, 0, 0,0,0]]
# gM = [[0, 1, 0, 0, 0, 0,0,0], [0, 0, 1, 0, 0, 0,0,0], [0, 0, 0, 1, 0, 0,0,0], [0, 0, 0, 0, 1, 0,0,0], [0, 0, 0, 0, 0, 1,0,0], [0, 0, 0, 0, 0, 0,1,0], [0, 0, 0, 0, 0, 0,0,1], [0, 0, 0, 0, 0, 0,0,0]]
# gPlus = [[0, 1, 0, 0, 0, 0,0,0], [0, 0, 1, 0, 0, 0,0,0], [0, 0, 0, 1, 0, 0,0,0], [0, 0, 0, 0, 1, 0,0,0], [0, 0, 0, 0, 0, 1,0,0], [0, 0, 0, 0, 0, 0,1,0], [0, 0, 0, 0, 0, 0,0,1], [0, 0, 0, 0, 0, 0,0,0]]

#Error checks
if n != len(g):
    print("\n*Update variable n to match with the matrix size*\n")

#create empty gM1 2D Array
gM1 = []
for x in range(n):
    col = []
    for y in range(n):
        col.append(None)
    gM1.append(col)

#compute Transitive Closure
def computeTransitiveClosure(newGm):

    #adj Matrix of g(m+1)
    for i in range(n):
        for j in range(n):
            gM1[i][j] = 0
            for k in range(n):
                gM1[i][j] = gM1[i][j] or (newGm[i][k] and g[k][j])

            #add to G Plus
            gPlus[i][j] = gPlus[i][j] or gM1[i][j]
    
    return gM1

#draw the graph
def drawGraph(tranGraphMat):
    graph = nx.DiGraph()

    #add nodes
    for x in range(n):
        graph.add_node(str(x + 1))

    #add edges
    for i in range(n):
        for j in range(n):
            if tranGraphMat[i][j] == 1:
                graph.add_edge(str(i+1), str(j+1))

    nx.draw(graph, with_labels=True, node_size=200, font_weight="bold", arrows=True, arrowsize=10)
    plt.margins(0.2)
    plt.show()

#compute n graphs
for x in range(n):
    #reset GM1 for new G(to compute new G using previous G)
    gM1 = []
    for x1 in range(n):
        col = []
        for y1 in range(n):
            col.append(None)
        gM1.append(col)

    #to compute new G using previous G
    if x == 0:
        newG = computeTransitiveClosure(g)
    else:
        newG = computeTransitiveClosure(newG)

print("Graph G -")
for i in g:
    print(i)

print("\nTransitive Closure G Plus -")
for i in gPlus:
    print(i)

drawGraph(gPlus)