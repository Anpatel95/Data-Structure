#Programming Assignment 1
#Aarav Patel
#CS610
import random

#service station class
class check_out_counter():
    def __init__(self, current_Customer = 0, service_time_dur = 0, occupied = False, total_duration_occupied = 0, total_customer_served = 0):
        self.current_Customer = current_Customer
        self.service_time_dur = service_time_dur
        self.occupied = occupied
        self.total_duration_occupied = total_duration_occupied
        self.total_customer_served = total_customer_served
        
#customer class
class customer():
    def __init__(self, id = 0, arrivalTime_timeType = 0, serviceTime_Duration = 0):
        self.id = id
        self.arrivalTime_timeType = arrivalTime_timeType
        self.serviceTime_Duration = serviceTime_Duration

#find shortest queue
def shortestQ(queue1, queue2, queue3, queue4, queue5):
    temp_Q_list = [len(queue1), len(queue2), len(queue3), len(queue4), len(queue5)]
    return temp_Q_list.index(min(temp_Q_list))

#random natural number    
def randNat(n):
    return random.randint(1, n)

#random postive
def randPos(n):
    return 1 + randNat(n-1)

#random number that will average to n
def randAvg(n):
    return int(randPos((2*n)-1))

#generate random event when it give n time true
def randEvent(n):
    return (round(random.random(), 2)) <= (1/n)

#simulation to test all policies 
def simulation(duration, arrivalRate, serviceRate):

    #Option 1-------------------------------------------------
    #single queue with 5 service station
    def option1():
        #initialize required variables
        timer, maxQsize, maxQ1waiting, total_cust, total_allwaitTime, total_serviceTime = 0, 0, 0, 0, 0, 0
        
        queue1 = []

        check_out_counter_1, check_out_counter_2, check_out_counter_3, check_out_counter_4, check_out_counter_5 = \
            check_out_counter(), check_out_counter(), check_out_counter(), check_out_counter(), check_out_counter()

        service_Stations = [check_out_counter_1, check_out_counter_2, check_out_counter_3, check_out_counter_4, check_out_counter_5]
        
        #Check-in opens------------------
        for x in range(duration):
                     
            #checks ramdom arrival time and creates  new customer
            if(randEvent(arrivalRate)):
                #create a customer
                service_Time = randAvg(serviceRate)
                createNewCustomer = customer(random.randint(1, 9999), x, service_Time)
                queue1.append(createNewCustomer)
                #note for stats
                total_cust += 1
                total_serviceTime += service_Time
            
            #check max queue 1 size
            if len(queue1) > maxQsize:
                maxQsize = len(queue1)

            #find open service station for the customer
            for x in range(len(service_Stations)):
                #checks customer on the counter
                if service_Stations[x].occupied and service_Stations[x].service_time_dur != 1:
                    service_Stations[x].service_time_dur -= 1
                    service_Stations[x].total_duration_occupied +=1
                else:
                    #check if customer is almost done
                    if (service_Stations[x].service_time_dur == 1):
                        service_Stations[x].total_duration_occupied +=1
                        service_Stations[x].service_time_dur = 0
                        service_Stations[x].occupied = False
                        service_Stations[x].current_Customer = 0
                        
                    #check if there is a open service station and customer is in Queue    
                    if (service_Stations[x].occupied == False and len(queue1) != 0):
                        service_Stations[x].current_Customer = queue1[0].id
                        service_Stations[x].service_time_dur = queue1[0].serviceTime_Duration
                        service_Stations[x].occupied = True
                        service_Stations[x].total_customer_served += 1
                        
                        #check max waiting time
                        if (timer - queue1[0].arrivalTime_timeType) > maxQ1waiting:
                            maxQ1waiting = timer - queue1[0].arrivalTime_timeType
                        #sum all wait time for stats
                        total_allwaitTime += (timer - queue1[0].arrivalTime_timeType)
                        queue1.pop(0)
            timer += 1
        #check-in closes------------------

        #process current customer on counter and in queue after the store door closes
        while(len(queue1) != 0 or check_out_counter_1.current_Customer != 0 or check_out_counter_2.current_Customer != 0\
            or check_out_counter_3.current_Customer != 0 or check_out_counter_4.current_Customer != 0 or check_out_counter_5.current_Customer != 0):
            #find open service station for the customer
            for x in range(len(service_Stations)):
                 #checks customer on the counter
                if service_Stations[x].occupied and service_Stations[x].service_time_dur != 1:
                    service_Stations[x].service_time_dur -= 1
                    service_Stations[x].total_duration_occupied +=1
                else:
                    #check if customer is almost done
                    if (service_Stations[x].service_time_dur == 1):
                        service_Stations[x].total_duration_occupied +=1
                        service_Stations[x].service_time_dur = 0
                        service_Stations[x].occupied = False
                        service_Stations[x].current_Customer = 0
                        
                    #check if there is a open service station and customer is in Queue  
                    if (service_Stations[x].occupied == False and len(queue1) != 0):
                        service_Stations[x].current_Customer = queue1[0].id
                        service_Stations[x].service_time_dur = queue1[0].serviceTime_Duration
                        service_Stations[x].occupied = True
                        service_Stations[x].total_customer_served += 1
                        
                        #check max waiting time
                        if (timer - queue1[0].arrivalTime_timeType) > maxQ1waiting:
                            maxQ1waiting = timer - queue1[0].arrivalTime_timeType
                        #sum all wait time for stats
                        total_allwaitTime += (timer - queue1[0].arrivalTime_timeType)
                        queue1.pop(0)
            timer += 1

        #Output Stats
        print("----------------------------Single Queue Output--------------------------")
        print("Total Duration of the Simulation:", timer, "mins")
        print("Max length of the Queue:", maxQsize)
        print("Max waiting time for the Queue:", maxQ1waiting, "mins")
        if total_allwaitTime == 0:
            print("Average waiting time for the Queue:", total_allwaitTime, "mins")
        else:
            print("Average waiting time for the Queue:", int(total_allwaitTime/total_cust), "mins")
        
        if total_serviceTime == 0:
            print("Average Service time for the Queue:", total_serviceTime, "mins")
        else:
            print("Average Service time for the Queue:", int(total_serviceTime/total_cust), "mins")
        
        for x in range(len(service_Stations)):
            print("Service station", x+1,"has rate of occupancy", round((service_Stations[x].total_duration_occupied/timer)*100, 2),"%")
        print()
    #option 1 function ends----------------------------------------
    
    #Option 2-----------------------------------------
    #option 2 has 5 queues and its assigned 5 counters
    def option2(queuing_policy):
        #initialize required variables
        timer = 0
        maxQueue_1_size, maxQueue_2_size, maxQueue_3_size, maxQueue_4_size, maxQueue_5_size = 0, 0, 0, 0, 0
        maxQ1waiting, maxQ2waiting, maxQ3waiting, maxQ4waiting, maxQ5waiting = 0, 0, 0, 0, 0
        total_queue1_cust, total_queue2_cust, total_queue3_cust, total_queue4_cust, total_queue5_cust  =  0, 0, 0, 0, 0
        next_queue = 1
        policy = ""
        
        total_Q1allwaitTime, total_Q2allwaitTime, total_Q3allwaitTime, total_Q4allwaitTime, total_Q5allwaitTime = 0, 0, 0, 0, 0
        total_Q1serviceTime, total_Q2serviceTime, total_Q3serviceTime, total_Q4serviceTime, total_Q5serviceTime = 0, 0, 0, 0, 0
        
        queue1, queue2, queue3, queue4, queue5 = [], [], [], [], []

        check_out_counter_1, check_out_counter_2, check_out_counter_3, check_out_counter_4, check_out_counter_5 = \
            check_out_counter(), check_out_counter(), check_out_counter(), check_out_counter(), check_out_counter()

        service_Stations = [check_out_counter_1, check_out_counter_2, check_out_counter_3, check_out_counter_4, check_out_counter_5]
        
        #Check-in opens ------------------
        for x in range(duration):
             
            #checks ramdom arrival time and creates new customer
            if(randEvent(arrivalRate)):
                service_Time =  randAvg(serviceRate)
                createNewCustomer = customer(random.randint(1, 9999), x, service_Time)
                
                #round-robin queuing policy
                if (queuing_policy == "2A"):
                    policy = "Round Robin Policy"
                    if next_queue == 1:
                        queue1.append(createNewCustomer)
                        next_queue = 2
                        total_queue1_cust += 1
                        total_Q1serviceTime += service_Time
                    elif next_queue == 2:
                        queue2.append(createNewCustomer)
                        next_queue = 3
                        total_queue2_cust += 1
                        total_Q2serviceTime += service_Time
                    elif next_queue == 3:
                        queue3.append(createNewCustomer)
                        next_queue = 4
                        total_queue3_cust += 1
                        total_Q3serviceTime += service_Time
                    elif next_queue == 4:
                        queue4.append(createNewCustomer)
                        next_queue = 5
                        total_queue4_cust += 1
                        total_Q4serviceTime += service_Time
                    elif next_queue == 5:
                        queue5.append(createNewCustomer)
                        next_queue = 1
                        total_queue5_cust += 1
                        total_Q5serviceTime += service_Time
                        
                #shortest queuing policy        
                elif (queuing_policy == "2B"):
                    policy = "Shortest Queue Policy"
                    shortestQueue = shortestQ(queue1, queue2, queue3, queue4, queue5)
                    if shortestQueue == 0:
                        queue1.append(createNewCustomer)
                        total_queue1_cust += 1
                        total_Q1serviceTime += service_Time
                    elif shortestQueue == 1:
                        queue2.append(createNewCustomer)
                        total_queue2_cust += 1
                        total_Q2serviceTime += service_Time
                    elif shortestQueue == 2:
                        queue3.append(createNewCustomer)
                        total_queue3_cust += 1
                        total_Q3serviceTime += service_Time
                    elif shortestQueue == 3:
                        queue4.append(createNewCustomer)
                        total_queue4_cust += 1
                        total_Q4serviceTime += service_Time
                    elif shortestQueue == 4:
                        queue5.append(createNewCustomer)
                        total_queue5_cust += 1
                        total_Q5serviceTime += service_Time
                
                #random queue selection policy
                elif (queuing_policy == "2C"):
                    policy = "Random Queue Policy"
                    randQueue = random.randint(0, 4)
                    if randQueue == 0:
                        queue1.append(createNewCustomer)
                        total_queue1_cust += 1
                        total_Q1serviceTime += service_Time
                    elif randQueue == 1:
                        queue2.append(createNewCustomer)
                        total_queue2_cust += 1
                        total_Q2serviceTime += service_Time
                    elif randQueue == 2:
                        queue3.append(createNewCustomer)
                        total_queue3_cust += 1
                        total_Q3serviceTime += service_Time
                    elif randQueue == 3:
                        queue4.append(createNewCustomer)
                        total_queue4_cust += 1
                        total_Q4serviceTime += service_Time
                    elif randQueue == 4:
                        queue5.append(createNewCustomer)
                        total_queue5_cust += 1
                        total_Q5serviceTime += service_Time
                            
            #check the max queue size of all queues
            if len(queue1) > maxQueue_1_size:
                maxQueue_1_size = len(queue1)
            if len(queue2) > maxQueue_2_size:
                maxQueue_2_size = len(queue2)
            if len(queue3) > maxQueue_3_size:
                maxQueue_3_size = len(queue3)
            if len(queue4) > maxQueue_4_size:
                maxQueue_4_size = len(queue4)
            if len(queue5) > maxQueue_5_size:
                maxQueue_5_size = len(queue5)

            #update service counter stat and confirm if waiting customer can use the service counter 1
            #checks customer on the counter
            if check_out_counter_1.occupied and check_out_counter_1.service_time_dur != 1:
                check_out_counter_1.service_time_dur -= 1
                check_out_counter_1.total_duration_occupied +=1
            else:
                #check if customer is almost done
                if (check_out_counter_1.service_time_dur == 1):
                    check_out_counter_1.total_duration_occupied +=1
                    check_out_counter_1.service_time_dur = 0
                    check_out_counter_1.occupied = False
                    check_out_counter_1.current_Customer = 0
                #check if there is a open service station and customer is in Queue   
                if (check_out_counter_1.occupied == False and len(queue1) != 0):
                    check_out_counter_1.current_Customer = queue1[0].id
                    check_out_counter_1.service_time_dur = queue1[0].serviceTime_Duration
                    check_out_counter_1.occupied = True
                    check_out_counter_1.total_customer_served += 1
                    #check max waiting time
                    if (timer - queue1[0].arrivalTime_timeType) > maxQ1waiting:
                        maxQ1waiting = timer - queue1[0].arrivalTime_timeType
                    #sum all wait time for stats
                    total_Q1allwaitTime += (timer - queue1[0].arrivalTime_timeType)
                    queue1.pop(0)
            
            #update service counter stat and confirm if waiting customer can use the service counter 2
            #checks customer on the counter
            if check_out_counter_2.occupied and check_out_counter_2.service_time_dur != 1:
                check_out_counter_2.service_time_dur -= 1
                check_out_counter_2.total_duration_occupied +=1
            else:
                #check if customer is almost done
                if (check_out_counter_2.service_time_dur == 1):
                    check_out_counter_2.total_duration_occupied +=1
                    check_out_counter_2.service_time_dur = 0
                    check_out_counter_2.occupied = False
                    check_out_counter_2.current_Customer = 0
                #check if there is a open service station and customer is in Queue   
                if (check_out_counter_2.occupied == False and len(queue2) != 0):
                    check_out_counter_2.current_Customer = queue2[0].id
                    check_out_counter_2.service_time_dur = queue2[0].serviceTime_Duration
                    check_out_counter_2.occupied = True
                    check_out_counter_2.total_customer_served += 1
                    
                    #check max waiting time
                    if (timer - queue2[0].arrivalTime_timeType) > maxQ2waiting:
                        maxQ2waiting = timer - queue2[0].arrivalTime_timeType
                    #sum all wait time for stats
                    total_Q2allwaitTime += (timer - queue2[0].arrivalTime_timeType)
                    queue2.pop(0)
                    
            #update service counter stat and confirm if waiting customer can use the service counter 3
            if check_out_counter_3.occupied and check_out_counter_3.service_time_dur != 1:
                check_out_counter_3.service_time_dur -= 1
                check_out_counter_3.total_duration_occupied +=1
            else:
                if (check_out_counter_3.service_time_dur == 1):
                    check_out_counter_3.total_duration_occupied +=1
                    check_out_counter_3.service_time_dur = 0
                    check_out_counter_3.occupied = False
                    check_out_counter_3.current_Customer = 0
                    
                if (check_out_counter_3.occupied == False and len(queue3) != 0):
                    check_out_counter_3.current_Customer = queue3[0].id
                    check_out_counter_3.service_time_dur = queue3[0].serviceTime_Duration
                    check_out_counter_3.occupied = True
                    check_out_counter_3.total_customer_served += 1

                    if (timer - queue3[0].arrivalTime_timeType) > maxQ3waiting:
                        maxQ3waiting = timer - queue3[0].arrivalTime_timeType
                    
                    total_Q3allwaitTime += (timer - queue3[0].arrivalTime_timeType)
                    queue3.pop(0)
                    
            #update service counter stat and confirm if waiting customer can use the service counter 4
            if check_out_counter_4.occupied and check_out_counter_4.service_time_dur != 1:
                check_out_counter_4.service_time_dur -= 1
                check_out_counter_4.total_duration_occupied +=1
            else:
                if (check_out_counter_4.service_time_dur == 1):
                    check_out_counter_4.total_duration_occupied +=1
                    check_out_counter_4.service_time_dur = 0
                    check_out_counter_4.occupied = False
                    check_out_counter_4.current_Customer = 0
                    
                if (check_out_counter_4.occupied == False and len(queue4) != 0):
                    check_out_counter_4.current_Customer = queue4[0].id
                    check_out_counter_4.service_time_dur = queue4[0].serviceTime_Duration
                    check_out_counter_4.occupied = True 
                    check_out_counter_4.total_customer_served += 1
                        
                    if (timer - queue4[0].arrivalTime_timeType) > maxQ4waiting:
                        maxQ4waiting = timer - queue4[0].arrivalTime_timeType
                   
                    total_Q4allwaitTime += (timer - queue4[0].arrivalTime_timeType) 
                    queue4.pop(0)
                    
            #update service counter stat and confirm if waiting customer can use the service counter 5
            if check_out_counter_5.occupied and check_out_counter_5.service_time_dur != 1:
                check_out_counter_5.service_time_dur -= 1
                check_out_counter_5.total_duration_occupied +=1
            else:
                if (check_out_counter_5.service_time_dur == 1):
                    check_out_counter_5.total_duration_occupied +=1
                    check_out_counter_5.service_time_dur = 0
                    check_out_counter_5.occupied = False
                    check_out_counter_5.current_Customer = 0
                    
                if (check_out_counter_5.occupied == False and len(queue5) != 0):
                    check_out_counter_5.current_Customer = queue5[0].id
                    check_out_counter_5.service_time_dur = queue5[0].serviceTime_Duration
                    check_out_counter_5.occupied = True
                    check_out_counter_5.total_customer_served += 1
                    
                    if (timer - queue5[0].arrivalTime_timeType) > maxQ5waiting:
                        maxQ5waiting = timer - queue5[0].arrivalTime_timeType
                    
                    total_Q5allwaitTime += (timer - queue5[0].arrivalTime_timeType)
                    queue5.pop(0)
            
            timer += 1
        #check-in closes----------------------------------

        #process current customer on the counters and all customer in waiting all queues since they are in the store
        while ((len(queue1) != 0 or check_out_counter_1.current_Customer != 0)\
            or (len(queue2) != 0 or check_out_counter_2.current_Customer != 0)\
            or (len(queue3) != 0 or check_out_counter_3.current_Customer != 0)\
            or (len(queue4) != 0 or check_out_counter_4.current_Customer != 0)\
            or (len(queue5) != 0 or check_out_counter_5.current_Customer != 0)):
            
            #update all service stations
            for x in range(len(service_Stations)):
                #check and update station 1
                if x == 0:
                    if check_out_counter_1.occupied and check_out_counter_1.service_time_dur != 1:
                        check_out_counter_1.service_time_dur -= 1
                        check_out_counter_1.total_duration_occupied +=1
                    else:
                        if (check_out_counter_1.service_time_dur == 1):
                            check_out_counter_1.total_duration_occupied +=1
                            check_out_counter_1.service_time_dur = 0
                            check_out_counter_1.occupied = False
                            check_out_counter_1.current_Customer = 0
                            
                        if (check_out_counter_1.occupied == False and len(queue1) != 0):
                            check_out_counter_1.current_Customer = queue1[0].id
                            check_out_counter_1.service_time_dur = queue1[0].serviceTime_Duration
                            check_out_counter_1.occupied = True
                            check_out_counter_1.total_customer_served += 1
                                
                            if (timer - queue1[0].arrivalTime_timeType) > maxQ1waiting:
                                maxQ1waiting = timer - queue1[0].arrivalTime_timeType
                            
                            total_Q1allwaitTime += (timer - queue1[0].arrivalTime_timeType)
                            queue1.pop(0)
                #check and update station 2
                elif x == 1:
                    if check_out_counter_2.occupied and check_out_counter_2.service_time_dur != 1:
                        check_out_counter_2.service_time_dur -= 1
                        check_out_counter_2.total_duration_occupied +=1
                    else:
                        if (check_out_counter_2.service_time_dur == 1):
                            check_out_counter_2.total_duration_occupied +=1
                            check_out_counter_2.service_time_dur = 0
                            check_out_counter_2.occupied = False
                            check_out_counter_2.current_Customer = 0
                            
                        if (check_out_counter_2.occupied == False and len(queue2) != 0):
                            check_out_counter_2.current_Customer = queue2[0].id
                            check_out_counter_2.service_time_dur = queue2[0].serviceTime_Duration
                            check_out_counter_2.occupied = True
                            check_out_counter_2.total_customer_served += 1
                                
                            if (timer - queue2[0].arrivalTime_timeType) > maxQ2waiting:
                                maxQ2waiting = timer - queue2[0].arrivalTime_timeType
                            
                            total_Q2allwaitTime += (timer - queue2[0].arrivalTime_timeType)            
                            queue2.pop(0)
                #check and update station 3
                elif x == 2:
                    if check_out_counter_3.occupied and check_out_counter_3.service_time_dur != 1:
                        check_out_counter_3.service_time_dur -= 1
                        check_out_counter_3.total_duration_occupied +=1
                    else:
                        if (check_out_counter_3.service_time_dur == 1):
                            check_out_counter_3.total_duration_occupied +=1
                            check_out_counter_3.service_time_dur = 0
                            check_out_counter_3.occupied = False
                            check_out_counter_3.current_Customer = 0
                            
                        if (check_out_counter_3.occupied == False and len(queue3) != 0):
                            check_out_counter_3.current_Customer = queue3[0].id
                            check_out_counter_3.service_time_dur = queue3[0].serviceTime_Duration
                            check_out_counter_3.occupied = True
                            check_out_counter_3.total_customer_served += 1
                            if (timer - queue3[0].arrivalTime_timeType) > maxQ3waiting:
                                maxQ3waiting = timer - queue3[0].arrivalTime_timeType
                            
                            total_Q3allwaitTime += (timer - queue3[0].arrivalTime_timeType)
                            queue3.pop(0)
                #check and update station 4
                elif x == 3:
                    if check_out_counter_4.occupied and check_out_counter_4.service_time_dur != 1:
                        check_out_counter_4.service_time_dur -= 1
                        check_out_counter_4.total_duration_occupied +=1
                    else:
                        if (check_out_counter_4.service_time_dur == 1):
                            check_out_counter_4.total_duration_occupied +=1
                            check_out_counter_4.service_time_dur = 0
                            check_out_counter_4.occupied = False
                            check_out_counter_4.current_Customer = 0
                            
                        if (check_out_counter_4.occupied == False and len(queue4) != 0):
                            check_out_counter_4.current_Customer = queue4[0].id
                            check_out_counter_4.service_time_dur = queue4[0].serviceTime_Duration
                            check_out_counter_4.occupied = True
                            check_out_counter_4.total_customer_served += 1
                                
                            if (timer - queue4[0].arrivalTime_timeType) > maxQ4waiting:
                                maxQ4waiting = timer - queue4[0].arrivalTime_timeType
                            
                            total_Q4allwaitTime += (timer - queue4[0].arrivalTime_timeType)
                            queue4.pop(0)
                #check and update station 5
                elif x == 4:
                    if check_out_counter_5.occupied and check_out_counter_5.service_time_dur != 1:
                        check_out_counter_5.service_time_dur -= 1
                        check_out_counter_5.total_duration_occupied +=1
                    else:
                        if (check_out_counter_5.service_time_dur == 1):
                            check_out_counter_5.total_duration_occupied +=1
                            check_out_counter_5.service_time_dur = 0
                            check_out_counter_5.occupied = False
                            check_out_counter_5.current_Customer = 0
                            
                        if (check_out_counter_5.occupied == False and len(queue5) != 0):
                            check_out_counter_5.current_Customer = queue5[0].id
                            check_out_counter_5.service_time_dur = queue5[0].serviceTime_Duration
                            check_out_counter_5.occupied = True
                            check_out_counter_5.total_customer_served += 1
                            
                            if (timer - queue5[0].arrivalTime_timeType) > maxQ5waiting:
                                maxQ5waiting = timer - queue5[0].arrivalTime_timeType
                            
                            total_Q5allwaitTime += (timer - queue5[0].arrivalTime_timeType)
                            queue5.pop(0)                    
            timer += 1
        
        #Output Stats
        print("----------------------------", policy ,"--------------------------")
        print("Total Duration of the Simulation:", timer)
        print("Max length of the Queue 1:", maxQueue_1_size)
        print("Max length of the Queue 2:", maxQueue_2_size)
        print("Max length of the Queue 3:", maxQueue_3_size)
        print("Max length of the Queue 4:", maxQueue_4_size)
        print("Max length of the Queue 5:", maxQueue_5_size)
        
        print()
        print("Max waiting time for the Queue 1:", maxQ1waiting, "mins")
        print("Max waiting time for the Queue 2:", maxQ2waiting, "mins")
        print("Max waiting time for the Queue 3:", maxQ3waiting, "mins")
        print("Max waiting time for the Queue 4:", maxQ4waiting, "mins")
        print("Max waiting time for the Queue 5:", maxQ5waiting, "mins")
        
        totalQwaiting_list = [total_Q1allwaitTime, total_Q2allwaitTime, total_Q3allwaitTime, total_Q4allwaitTime, total_Q5allwaitTime]
        total_Cust_perQ = [total_queue1_cust, total_queue2_cust, total_queue3_cust, total_queue4_cust, total_queue5_cust]
        total_seriveTime_perQ = [total_Q1serviceTime, total_Q2serviceTime, total_Q3serviceTime, total_Q4serviceTime, total_Q5serviceTime]
        
        print()
        for i in range(len(totalQwaiting_list)):
            if totalQwaiting_list[i] == 0:
                print("Average waiting time for the Queue",i+1,":", totalQwaiting_list[i], "mins")
            else:
                print("Average waiting time for the Queue",i+1,":", int(totalQwaiting_list[i]/total_Cust_perQ[i]), "mins")
        
        print()
        for y in range(len(total_seriveTime_perQ)):
            if total_seriveTime_perQ[y] == 0:
                print("Average Service time for the Queue",y+1,":", total_seriveTime_perQ[y], "mins")
            else:
                print("Average Service time for the Queue",y+1,":", int(total_seriveTime_perQ[y]/total_Cust_perQ[y]), "mins")
          
        print()
        for x in range(len(service_Stations)):
            if service_Stations[x].total_duration_occupied == 0:
                print("Service station", x+1,"has rate of occupancy", service_Stations[x].total_duration_occupied,"%")
            else:
                print("Service station", x+1,"has rate of occupancy", round((service_Stations[x].total_duration_occupied/timer)*100, 2),"%")
        print()
    #Option 2 ends
   
    #run option 1 queuing policy 1 queue and 5 counters
    option1()
    #run option 2 with 2A round robin queue policy
    option2("2A")
    #run option 2 with 2B shortest queue policy
    option2("2B")
    #run option 2 with 2C random queue policy
    option2("2C")

if __name__ == '__main__':
    #inputs for simulation
    arrivalRate = 2
    duration = 10000
    service_rate = 80
    simulation(duration, arrivalRate, service_rate)